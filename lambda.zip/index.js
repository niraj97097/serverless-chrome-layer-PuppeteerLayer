const puppeteer = require('puppeteer');
const AWS = require('aws-sdk');
const fs = require('fs');

// Configure AWS SES
const ses = new AWS.SES({ region: 'us-east-1' });

const SENDER = 'sender@example.com';
const RECIPIENT = 'recipient@example.com';
const SUBJECT = 'CloudWatch Dashboard Weekly Report';

async function captureScreenshot(url, filePath) {
  const browser = await puppeteer.launch({
    args: ['--no-sandbox', '--disable-dev-shm-usage'],
    headless: true,
  });
  const page = await browser.newPage();
  await page.goto(url, { waitUntil: 'networkidle2' });
  await page.screenshot({ path: filePath, fullPage: true });
  await browser.close();
}

exports.handler = async (event) => {
  const dashboardUrl = 'https://console.aws.amazon.com/cloudwatch/home?region=us-east-1#dashboards:name=YourDashboardName';
  const screenshotPath = '/tmp/screenshot.png';

  // Capture the screenshot
  await captureScreenshot(dashboardUrl, screenshotPath);

  // Read and encode the screenshot
  const screenshotData = fs.readFileSync(screenshotPath);
  const screenshotBase64 = screenshotData.toString('base64');

  // Prepare email content with embedded image
  const bodyHtml = `
    <html>
    <body>
        <h1>CloudWatch Dashboard Weekly Report</h1>
        <p>Attached is the screenshot of the CloudWatch dashboard:</p>
        <img src="data:image/png;base64,${screenshotBase64}" alt="CloudWatch Dashboard Screenshot" />
    </body>
    </html>
  `;

  // Send email using Amazon SES
  const params = {
    Source: SENDER,
    Destination: {
      ToAddresses: [RECIPIENT],
    },
    Message: {
      Subject: {
        Data: SUBJECT,
        Charset: 'UTF-8',
      },
      Body: {
        Html: {
          Data: bodyHtml,
          Charset: 'UTF-8',
        },
      },
    },
  };

  try {
    await ses.sendEmail(params).promise();
    return {
      statusCode: 200,
      body: 'Report generated and sent successfully.',
    };
  } catch (error) {
    return {
      statusCode: 500,
      body: `Failed to send email: ${error.message}`,
    };
  }
};