PUPPETEER_SKIP_CHROMIUM_DOWNLOAD = 1;
const chromium = require('@sparticuz/chromium');
const puppeteer = require('puppeteer');
const AWS = require('aws-sdk');
const { SESClient, SendEmailCommand } = require('@aws-sdk/client-ses');
const fs = require('fs').promises;

const SES_REGION = 'us-east-1';
const SENDER = 'niraj.kumar@regeneron.com';
const RECIPIENT = 'niraj.kumar@regeneron.com';
const SUBJECT = 'GD OSDH Redshift Utilization Weekly Report';
const DASHBOARD_URL = 'https://console.aws.amazon.com/cloudwatch/home?region=us-east-1#dashboards:name=GD-OSDH-Redshift';
const ASSUMED_ROLE_ARN = 'arn:aws:iam::123456789012:role/YourRoleName'; // Replace with your role ARN

// Configure AWS SES Client
const sesClient = new SESClient({ region: SES_REGION });

const getTemporaryCredentials = async () => {
    try {
        const sts = new AWS.STS();
        const assumedRole = await sts.assumeRole({
            RoleArn: ASSUMED_ROLE_ARN,
            RoleSessionName: 'LambdaSession'
        }).promise();
        
        return assumedRole.Credentials;
    } catch (error) {
        console.error('Error assuming role:', error);
        throw new Error('Failed to assume role');
    }
};

const captureScreenshot = async (url, filePath, credentials) => {
    console.log('Launching Puppeteer...');
    const browser = await puppeteer.launch({
        args: chromium.args,
        executablePath: await chromium.executablePath(),
        headless: chromium.headless,
    });
    const page = await browser.newPage();

    console.log('Setting AWS credentials...');
    await page.evaluateOnNewDocument((accessKeyId, secretAccessKey, sessionToken) => {
        localStorage.setItem('aws.credentials', JSON.stringify({
            accessKeyId: accessKeyId,
            secretAccessKey: secretAccessKey,
            sessionToken: sessionToken
        }));
    }, credentials.AccessKeyId, credentials.SecretAccessKey, credentials.SessionToken);

    console.log('Navigating to the CloudWatch dashboard...');
    await page.goto(url, { waitUntil: 'networkidle2' });

    console.log('Capturing screenshot...');
    await page.screenshot({ path: filePath, fullPage: true });
    await browser.close();
    console.log('Screenshot captured successfully');
};

exports.handler = async (event) => {
    const screenshotPath = '/tmp/screenshot.png';

    try {
        console.log('Assuming role...');
        const credentials = await getTemporaryCredentials();
        console.log('Role assumed successfully:', credentials);

        console.log('Capturing screenshot...');
        await captureScreenshot(DASHBOARD_URL, screenshotPath, credentials);

        console.log('Reading screenshot...');
        const screenshotData = await fs.readFile(screenshotPath);
        const screenshotBase64 = screenshotData.toString('base64');

        console.log('Preparing email content...');
        const bodyHtml = `
            <html>
            <body>
                <h1>CloudWatch Dashboard Weekly Report</h1>
                <p>Attached is Storage and CPU utilization of GD OSDH Redshift Cluster for Dev and Prod:</p>
                <img src="data:image/png;base64,${screenshotBase64}" alt="CloudWatch Dashboard Screenshot" />
            </body>
            </html>
        `;

        console.log('Sending email using Amazon SES...');
        const params = {
            Source: SENDER,
            Destination: {
                ToAddresses: [RECIPIENT],
            },
            Message: {
                Subject: {
                    Data: SUBJECT,
                    Charset: 'UTF-8',
                },
                Body: {
                    Html: {
                        Data: bodyHtml,
                        Charset: 'UTF-8',
                    },
                },
            },
        };

        const command = new SendEmailCommand(params);
        await sesClient.send(command);
        console.log('Email sent successfully');

        return {
            statusCode: 200,
            body: 'Report generated and sent successfully.',
        };
    } catch (error) {
        console.error('Error:', error);
        return {
            statusCode: 500,
            body: `Failed to generate report: ${error.message}`,
        };
    }
};