PUPPETEER_SKIP_CHROMIUM_DOWNLOAD = 1;
const chromium = require('@sparticuz/chromium');
const puppeteer = require('puppeteer');
const AWS = require('aws-sdk');
const { SESClient, SendEmailCommand } = require('@aws-sdk/client-ses');
const fs = require('fs').promises;

// Configure AWS SES Client
const sesClient = new SESClient({ region: 'us-east-1' });

const SENDER = 'niraj.kumar@regeneron.com';
const RECIPIENT = 'niraj.kumar@regeneron.com';
const SUBJECT = 'GD OSDH Redshift Utilization Weekly Report';

const captureScreenshot = async (url, filePath) => {
    const browser = await puppeteer.launch({
        args: chromium.args,
        executablePath: await chromium.executablePath(),
        headless: chromium.headless,
    });
    const page = await browser.newPage();

    // Set up IAM role credentials for the session
    const credentials = await new AWS.CredentialProviderChain().resolvePromise();
    const sessionToken = credentials.sessionToken;
    const accessKeyId = credentials.accessKeyId;
    const secretAccessKey = credentials.secretAccessKey;

    // Set the AWS credentials in the environment
    await page.evaluateOnNewDocument((accessKeyId, secretAccessKey, sessionToken) => {
        localStorage.setItem('aws.credentials', JSON.stringify({
            accessKeyId: accessKeyId,
            secretAccessKey: secretAccessKey,
            sessionToken: sessionToken
        }));
    }, accessKeyId, secretAccessKey, sessionToken);

    // Navigate to the CloudWatch dashboard
    await page.goto(url, { waitUntil: 'networkidle2' });
    await page.screenshot({ path: filePath, fullPage: true });
    await browser.close();
};

exports.handler = async (event) => {
    const dashboardUrl = 'https://console.aws.amazon.com/cloudwatch/home?region=us-east-1#dashboards:name=GD-OSDH-Redshift';
    const screenshotPath = '/tmp/screenshot.png';

    // Capture the screenshot
    await captureScreenshot(dashboardUrl, screenshotPath);

    // Read and encode the screenshot
    const screenshotData = await fs.readFile(screenshotPath);
    const screenshotBase64 = screenshotData.toString('base64');

    // Prepare email content with embedded image
    const bodyHtml = `
        <html>
        <body>
            <h1>CloudWatch Dashboard Weekly Report</h1>
            <p>Attached is Storage and CPU utilization of GD OSDH Redshift Cluster for Dev and Prod:</p>
            <img src="data:image/png;base64,${screenshotBase64}" alt="CloudWatch Dashboard Screenshot" />
        </body>
        </html>
    `;

    // Send email using Amazon SES
    const params = {
        Source: SENDER,
        Destination: {
            ToAddresses: [RECIPIENT],
        },
        Message: {
            Subject: {
                Data: SUBJECT,
                Charset: 'UTF-8',
            },
            Body: {
                Html: {
                    Data: bodyHtml,
                    Charset: 'UTF-8',
                },
            },
        },
    };

    const command = new SendEmailCommand(params);

    try {
        await sesClient.send(command);
        return {
            statusCode: 200,
            body: 'Report generated and sent successfully.',
        };
    } catch (error) {
        return {
            statusCode: 500,
            body: `Failed to send email: ${error.message}`,
        };
    }
};